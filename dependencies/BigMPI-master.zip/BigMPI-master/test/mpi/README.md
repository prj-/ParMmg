These tests are to verify the behavior of MPI itself, such as to make
sure various functions are count-safe and that the datatype functions
work as desired.
