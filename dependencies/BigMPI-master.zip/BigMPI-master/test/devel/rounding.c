#include <stdio.h>

int main(int argc, char * argv[])
{
    printf("7/3 = %d\n",7/3);
    printf("8/3 = %d\n",8/3);
    return 0;
}

